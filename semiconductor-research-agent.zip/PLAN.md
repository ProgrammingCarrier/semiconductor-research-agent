# Delivery plan - Semiconductor Sector Research Agent

## Objective

Evaluate whether quarter-over-quarter changes in inventory, gross margin, and forward guidance are useful leading indicators of the *next* earnings surprise and 5-day market-adjusted return across NVDA, AMD, INTC, AVGO, QCOM, MU, TXN, and ON.

## MVP delivered here

1. **Point-in-time data contract** - every fundamental has a period end, public availability timestamp, and source IDs. The supervisor excludes data that was not public on the selected as-of date.
2. **Specialist workflow** - a data-quality agent validates the fundamental panel; a fundamentals agent calculates drivers; an earnings-material retriever is ready for cited source search; a citation verifier checks source timing and completeness; and a walk-forward validator evaluates an out-of-sample rule.
3. **Hypothesis metrics** - inventory QoQ %, gross-margin delta in basis points, guidance-midpoint change, composite triage score, EPS surprise %, and 5-day benchmark-adjusted return.
4. **Investor-facing outputs** - a peer table, counter-thesis prompts, a cited source register, machine-readable JSON, and a standalone HTML dashboard.
5. **Safe development path** - a complete synthetic fixture runs offline. The included SEC Company Facts adapter fetches reported fundamentals, while guidance, consensus, returns, and earnings materials remain separate, licensed/primary-source joins.

## Production completion sequence

1. Register permitted market-data and transcript/earnings-release sources, with source-specific licenses and retention rules.
2. Ingest releases/transcripts into a document store; preserve document date, URL, issuer, and immutable excerpt before embedding/retrieval.
3. Map non-GAAP guidance definitions per issuer and normalize fiscal calendars, units, and stock splits.
4. Add consensus EPS and a survivorship-safe price/benchmark dataset; define event window and timing convention explicitly.
5. Pre-register signal direction, rebalance cadence, and evaluation metric; then run expanding-window validation with transaction-cost and sensitivity analyses.
6. Add review/approval gates: data-quality exceptions, citation verification, human analyst sign-off, and versioned research snapshots.

## Guardrails

- This project produces research support, not investment advice or trade instructions.
- A signal is calculated only from information available by its as-of timestamp.
- The next earnings outcome is linked after the observation date, preventing same-event look-ahead.
- Synthetic fixture values are visibly labeled and must never be mixed with live research.

# Semiconductor Sector Research Agent

A runnable, auditable MVP for the résumé project: a point-in-time research workflow across eight U.S.-listed semiconductor companies.

It tests whether inventory, gross-margin, and forward-guidance changes help explain the **next** earnings surprise and 5-day market-adjusted return. It is intentionally conservative: citations, data availability dates, and walk-forward validation are first-class objects rather than a presentation layer added afterward.

> The supplied data fixture is synthetic, the dashboard is a workflow demonstration, and this repository is not investment advice. Do not use the bundled data to make investment decisions.

## Quick start

No third-party Python packages are required.

```bash
cd /Users/zykdemac/Documents/Codex/2026-11-07/bas/outputs/semiconductor-research-agent
PYTHONPATH=src python3 -m semiconductor_research.cli demo --as-of 2025-12-31 --output reports/demo
open reports/demo/dashboard.html
```

The command writes three artifacts:

- `research.json` - structured signals, outcomes, citations, data issues, and validation folds
- `earnings_brief.md` - peer comparison, counter-theses, controls, and source register
- `dashboard.html` - a standalone investor-facing dashboard, usable without a server

## Architecture

```text
fundamentals + earnings materials + market outcomes
                  |
       point-in-time admission gate
                  |
data quality -> fundamental signals -> citation verification
                  |
       walk-forward validation
                  |
       brief + JSON + dashboard
```

The agents are modular Python services rather than opaque prompts:

- `DataQualityAgent` detects duplicate quarters, invalid units/values, absent citations, and invalid timestamps.
- `FundamentalAnalysisAgent` calculates the three documented drivers and a transparent equal-weight composite.
- `EarningsMaterialRetriever` provides dependency-free lexical retrieval over cited excerpts; it has a stable interface for replacement with embeddings.
- `CitationVerificationAgent` checks existence, public timing, HTTPS sources, and excerpt quality.
- `WalkForwardValidator` produces expanding-window folds and never uses the current fold to set its threshold.

## Live fundamentals adapter

The SEC adapter is deliberately narrow: it retrieves revenue, gross profit, and inventory from Company Facts. SEC data does not provide investor consensus, total-return history, or issuer forward guidance in a normalized form. Those are separate joins with their own licensing and source checks.

```bash
PYTHONPATH=src python3 -m semiconductor_research.cli sec \
  --ticker NVDA --ticker AMD \
  --as-of 2026-11-07 \
  --user-agent 'Your Name your.email@example.com' \
  --output reports/sec
```

The adapter needs network access and an SEC-compliant descriptive User-Agent. Review the resulting quality warnings: company-specific XBRL tags and fiscal calendars need issuer-level mapping before production use.

## Methodology

- **Inventory QoQ:** `(current inventory - previous inventory) / previous inventory`
- **Gross-margin delta:** `10,000 × (current gross margin - previous gross margin)`
- **Guidance change:** `(current guidance midpoint - previous midpoint) / previous midpoint`
- **Composite:** equal-weight average of `-inventory QoQ`, margin delta scaled by 1,000 bps, and guidance change. This is a triage score, not a forecast or price target.
- **Positive outcome:** next earnings actual EPS exceeds consensus **and** 5-day return less benchmark return is positive.

The validator uses the median composite score of prior dated folds as the current-fold threshold. This deliberately simple rule makes the leakage controls inspectable. A production model should be preregistered, calibrated on a separate period, and evaluated with sensitivity analysis, costs, and confidence intervals.

## Tests

```bash
PYTHONPATH=src python3 -m unittest discover -s tests -v
```

See [PLAN.md](PLAN.md) for the delivered scope and production completion sequence.

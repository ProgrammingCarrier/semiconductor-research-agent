from __future__ import annotations

from datetime import date

from .models import DataIssue, FundamentalObservation


class DataQualityAgent:
    """Rejects invalid or future-dated fundamentals before analysis."""

    def validate(self, observations: list[FundamentalObservation], as_of: date) -> list[DataIssue]:
        issues: list[DataIssue] = []
        seen: set[tuple[str, date]] = set()
        for obs in observations:
            key = (obs.ticker, obs.period_end)
            if key in seen:
                issues.append(DataIssue("error", obs.ticker, "Duplicate company-quarter observation.", "period_end"))
            seen.add(key)
            if obs.available_at > as_of:
                issues.append(DataIssue("error", obs.ticker, "Observation was not public as of the research date.", "available_at"))
            if obs.available_at < obs.period_end:
                issues.append(DataIssue("error", obs.ticker, "Availability date precedes period end.", "available_at"))
            if obs.revenue_m is not None and obs.revenue_m <= 0:
                issues.append(DataIssue("error", obs.ticker, "Revenue must be positive.", "revenue_m"))
            if obs.inventory_m is not None and obs.inventory_m < 0:
                issues.append(DataIssue("error", obs.ticker, "Inventory cannot be negative.", "inventory_m"))
            if obs.gross_profit_m is not None and obs.revenue_m is not None and obs.gross_profit_m > obs.revenue_m:
                issues.append(DataIssue("warning", obs.ticker, "Gross profit exceeds revenue; confirm unit scaling.", "gross_profit_m"))
            if not obs.citation_ids:
                issues.append(DataIssue("error", obs.ticker, "Fundamentals require at least one citation.", "citation_ids"))
        return issues

from __future__ import annotations

import html
import json
from pathlib import Path

from .metrics import peer_zscores
from .models import ResearchResult, SignalRecord


def write_research_package(result: ResearchResult, output_dir: Path, data_label: str = "Synthetic demonstration fixture") -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    payload = _payload(result, data_label)
    (output_dir / "research.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    (output_dir / "earnings_brief.md").write_text(markdown_report(result, data_label), encoding="utf-8")
    (output_dir / "dashboard.html").write_text(dashboard_html(result, data_label), encoding="utf-8")


def _payload(result: ResearchResult, data_label: str) -> dict:
    return {
        "as_of": result.as_of.isoformat(),
        "data_label": data_label,
        "signals": [signal.to_dict() for signal in result.signals],
        "citations": {source_id: citation.to_dict() for source_id, citation in result.citations.items()},
        "data_issues": [issue.__dict__ for issue in result.data_issues],
        "walk_forward": result.walk_forward,
    }


def latest_signals(result: ResearchResult) -> list[SignalRecord]:
    if not result.signals:
        return []
    latest_date = max(signal.available_at for signal in result.signals)
    return sorted((signal for signal in result.signals if signal.available_at == latest_date), key=lambda row: row.composite_score or -999, reverse=True)


def markdown_report(result: ResearchResult, data_label: str) -> str:
    signals = latest_signals(result)
    zscores = peer_zscores(signals)
    lines = [
        "# U.S. Semiconductor Sector Earnings Brief",
        "",
        f"**As of:** {result.as_of.isoformat()}  ",
        f"**Dataset:** {data_label}",
        "",
        "> This package is a research workflow demonstration, not investment advice. The bundled fixture is synthetic and must be replaced with licensed and primary-source data before any investment use.",
        "",
        "## Latest peer comparison",
        "",
        "| Ticker | Inventory QoQ | Gross-margin delta | Guidance change | Composite | Peer z-score | Next EPS surprise | 5D market-adjusted return |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for signal in signals:
        outcome = signal.outcome
        lines.append(
            f"| {signal.ticker} | {_pct(signal.inventory_qoq)} | {_bps(signal.gross_margin_delta_bps)} | {_pct(signal.guidance_change)} | "
            f"{_number(signal.composite_score)} | {_number(zscores.get((signal.ticker, signal.available_at)))} | "
            f"{_pct(outcome.eps_surprise_pct) if outcome else 'N/A'} | {_pct(outcome.market_adjusted_return_5d) if outcome else 'N/A'} |"
        )
    lines.extend(["", "## Read-through and counter-theses", ""])
    if signals:
        leader, laggard = signals[0], signals[-1]
        lines.extend([
            f"- **Relative leader: {leader.ticker}.** Its composite score combines {_pct(leader.inventory_qoq)} inventory change, {_bps(leader.gross_margin_delta_bps)} margin movement, and {_pct(leader.guidance_change)} guidance movement. **Counter-thesis:** the score can mistake mix or accounting timing for sustainable demand; corroborate with management commentary and end-demand indicators.",
            f"- **Relative laggard: {laggard.ticker}.** The same driver stack is weaker on this observation. **Counter-thesis:** an inventory build may be intentional channel positioning, while short-term margin pressure can precede utilization recovery.",
            "- **Decision rule:** treat the composite as a triage signal, not a price target. Require a cited earnings-material review, estimate-revision context, and a liquidity/risk check before acting.",
        ])
    lines.extend(["", "## Point-in-time and validation controls", ""])
    lines.extend([
        "- Fundamentals are admitted only when `available_at <= as_of`; future filings are excluded before signals are calculated.",
        "- A score links to the first *subsequent* earnings outcome, avoiding use of same-event reporting details to explain that event.",
        "- The walk-forward threshold is the median composite score in earlier folds only; it is never calibrated on the current fold.",
        "- Data-quality checks flag duplicate periods, impossible values, missing sources, and future-dated observations. Citation verification checks existence, timing, HTTPS URLs, and support excerpts.",
        "",
        "## Walk-forward result",
        "",
        "```json",
        json.dumps({key: value for key, value in result.walk_forward.items() if key != "predictions"}, indent=2),
        "```",
        "",
        "## Source register (latest peer set)",
        "",
    ])
    source_ids = sorted({source_id for signal in signals for source_id in signal.citation_ids})
    for source_id in source_ids:
        citation = result.citations[source_id]
        lines.append(f"- [{citation.title}]({citation.url}) - available {citation.published_at.isoformat()} - `{source_id}`")
    return "\n".join(lines) + "\n"


def dashboard_html(result: ResearchResult, data_label: str) -> str:
    data = json.dumps(_payload(result, data_label)).replace("</", "<\\/")
    return f"""<!doctype html>
<html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
<title>Semiconductor earnings research</title>
<style>
body{{font-family:ui-sans-serif,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;margin:0;background:#f6f8fb;color:#172033}} main{{max-width:1240px;margin:auto;padding:32px 22px 56px}}h1{{margin:0;font-size:30px}}.sub{{color:#596579;margin-top:8px}}.notice{{border-left:4px solid #e6a23c;background:#fff8e8;padding:12px 14px;margin:24px 0;border-radius:4px}}.cards{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin:20px 0}}.card{{background:#fff;border:1px solid #e5e9f0;padding:18px;border-radius:10px}}.k{{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#68758a}}.v{{font-size:24px;font-weight:650;margin-top:6px}}table{{width:100%;border-collapse:collapse;background:#fff;border:1px solid #e5e9f0;border-radius:10px;overflow:hidden}}th,td{{padding:12px 10px;border-bottom:1px solid #e8ecf2;text-align:right;font-variant-numeric:tabular-nums}}th{{background:#15233b;color:#fff;font-size:12px;text-transform:uppercase;letter-spacing:.04em}}th:first-child,td:first-child{{text-align:left}}tr:hover{{background:#f4f8ff}}.good{{color:#147a47;font-weight:600}}.bad{{color:#bd3b3b;font-weight:600}}details{{margin-top:22px;background:#fff;border:1px solid #e5e9f0;border-radius:10px;padding:14px}}summary{{cursor:pointer;font-weight:650}}pre{{overflow:auto;font-size:12px}}@media(max-width:700px){{.cards{{grid-template-columns:1fr}}table{{font-size:12px}}th,td{{padding:8px 5px}}}}
</style></head><body><main><h1>Semiconductor Sector Research Agent</h1><div class=\"sub\" id=\"sub\"></div><div class=\"notice\">Research workflow demonstration only - not investment advice. Confirm every conclusion against live, licensed, and primary-source data.</div><section class=\"cards\" id=\"cards\"></section><h2>Latest peer comparison</h2><div style=\"overflow-x:auto\"><table><thead><tr><th>Ticker</th><th>Inventory QoQ</th><th>Gross margin Δ</th><th>Guidance Δ</th><th>Composite</th><th>EPS surprise</th><th>5D market adj.</th></tr></thead><tbody id=\"rows\"></tbody></table></div><details><summary>Walk-forward validation</summary><pre id=\"validation\"></pre></details><details><summary>Data quality and citation controls</summary><pre id=\"issues\"></pre></details></main><script>const data={data};const pct=v=>v==null?'—':(v*100).toFixed(1)+'%';const bps=v=>v==null?'—':Math.round(v)+' bps';const num=v=>v==null?'—':v.toFixed(3);const latest=Math.max(...data.signals.map(x=>Date.parse(x.available_at)));const rows=data.signals.filter(x=>Date.parse(x.available_at)===latest).sort((a,b)=>(b.composite_score??-999)-(a.composite_score??-999));document.querySelector('#sub').textContent=`As of ${{data.as_of}} • ${{data.data_label}} • ${{rows.length}} names`;document.querySelector('#cards').innerHTML=[['Coverage',rows.length+' names'],['Signals',data.signals.length],['Walk-forward accuracy',data.walk_forward.accuracy==null?'Insufficient history':pct(data.walk_forward.accuracy)] .map(([k,v])=>`<div class=\"card\"><div class=\"k\">${{k}}</div><div class=\"v\">${{v}}</div></div>`).join('');document.querySelector('#rows').innerHTML=rows.map(x=>`<tr><td><b>${{x.ticker}}</b></td><td>${{pct(x.inventory_qoq)}}</td><td>${{bps(x.gross_margin_delta_bps)}}</td><td>${{pct(x.guidance_change)}}</td><td class=\"${{(x.composite_score??0)>=0?'good':'bad'}}\">${{num(x.composite_score)}}</td><td>${{pct(x.outcome?.eps_surprise_pct)}}</td><td class=\"${{(x.outcome?.market_adjusted_return_5d??0)>=0?'good':'bad'}}\">${{pct(x.outcome?.market_adjusted_return_5d)}}</td></tr>`).join('');document.querySelector('#validation').textContent=JSON.stringify(data.walk_forward,null,2);document.querySelector('#issues').textContent=JSON.stringify(data.data_issues,null,2);</script></body></html>"""


def _pct(value: float | None) -> str:
    return "N/A" if value is None else f"{value * 100:.1f}%"


def _bps(value: float | None) -> str:
    return "N/A" if value is None else f"{value:.0f} bps"


def _number(value: float | None) -> str:
    return "N/A" if value is None else f"{value:.3f}"

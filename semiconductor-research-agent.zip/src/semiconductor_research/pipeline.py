from __future__ import annotations

from datetime import date

from .backtest import WalkForwardValidator
from .citations import CitationVerificationAgent
from .metrics import FundamentalAnalysisAgent
from .models import Citation, EarningsOutcome, FundamentalObservation, ResearchResult
from .quality import DataQualityAgent


class ResearchPipeline:
    """Supervisor-routed pipeline with auditable outputs at each specialist boundary."""

    def __init__(self) -> None:
        self.quality_agent = DataQualityAgent()
        self.fundamental_agent = FundamentalAnalysisAgent()
        self.citation_agent = CitationVerificationAgent()
        self.validator = WalkForwardValidator()

    def run(
        self,
        observations: list[FundamentalObservation],
        outcomes: list[EarningsOutcome],
        citations: dict[str, Citation],
        as_of: date,
    ) -> ResearchResult:
        visible_observations = [item for item in observations if item.available_at <= as_of]
        visible_outcomes = [item for item in outcomes if item.event_date <= as_of]
        issues = self.quality_agent.validate(visible_observations, as_of)
        signals = self.fundamental_agent.build_signals(visible_observations, visible_outcomes, as_of)
        citation_ids = {source_id for observation in visible_observations for source_id in observation.citation_ids}
        citation_ids.update(source_id for outcome in visible_outcomes for source_id in outcome.citation_ids)
        citation_ids.update(source_id for signal in signals for source_id in signal.citation_ids)
        issues.extend(self.citation_agent.verify(citation_ids, citations, as_of))
        return ResearchResult(
            as_of=as_of, signals=signals, citations=citations, data_issues=issues,
            walk_forward=self.validator.evaluate(signals),
        )

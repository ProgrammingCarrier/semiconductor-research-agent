from __future__ import annotations

import argparse
from datetime import date
from pathlib import Path

from .pipeline import ResearchPipeline
from .reporting import write_research_package
from .sample_data import UNIVERSE, demo_data
from .sec import SecCompanyFactsProvider


def parse_date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("Expected ISO date: YYYY-MM-DD") from error


def main() -> None:
    parser = argparse.ArgumentParser(description="Point-in-time semiconductor earnings research")
    subparsers = parser.add_subparsers(dest="command", required=True)
    demo = subparsers.add_parser("demo", help="Run the complete offline synthetic demonstration")
    demo.add_argument("--as-of", type=parse_date, default=date(2025, 12, 31))
    demo.add_argument("--output", type=Path, default=Path("reports/demo"))
    sec = subparsers.add_parser("sec", help="Fetch SEC Company Facts fundamentals (optional live adapter)")
    sec.add_argument("--as-of", type=parse_date, default=date.today())
    sec.add_argument("--ticker", choices=UNIVERSE, action="append", default=[])
    sec.add_argument("--user-agent", required=True, help="Descriptive contact string containing an email")
    sec.add_argument("--output", type=Path, default=Path("reports/sec"))
    args = parser.parse_args()

    if args.command == "demo":
        observations, outcomes, citations = demo_data()
        result = ResearchPipeline().run(observations, outcomes, citations, args.as_of)
        write_research_package(result, args.output, "Synthetic offline fixture - never use for investment decisions")
        print(f"Wrote research package to {args.output.resolve()}")
        return

    provider = SecCompanyFactsProvider()
    observations, citations = [], {}
    for ticker in args.ticker or list(UNIVERSE):
        company_observations, company_citations = provider.fetch(ticker, args.as_of, args.user_agent)
        observations.extend(company_observations)
        citations.update(company_citations)
    result = ResearchPipeline().run(observations, [], citations, args.as_of)
    write_research_package(result, args.output, "SEC Company Facts only - guidance, consensus, and market outcomes not yet joined")
    print(f"Wrote SEC fundamentals package to {args.output.resolve()}")


if __name__ == "__main__":
    main()

"""Optional SEC Company Facts adapter for live fundamentals.

This adapter deliberately does not supply guidance, consensus, or market returns.
Those must come from authorised earnings-material and market-data sources.
"""

from __future__ import annotations

import json
from datetime import date
from urllib.request import Request, urlopen

from .models import Citation, FundamentalObservation


CIKS = {
    "NVDA": "0001045810", "AMD": "0000002488", "INTC": "0000050863", "AVGO": "0001730168",
    "QCOM": "0000804328", "MU": "0000723125", "TXN": "0000097476", "ON": "0001097864",
}


class SecCompanyFactsProvider:
    def fetch(self, ticker: str, as_of: date, user_agent: str) -> tuple[list[FundamentalObservation], dict[str, Citation]]:
        if ticker not in CIKS:
            raise ValueError(f"Ticker {ticker} is outside the configured semiconductor universe.")
        if "@" not in user_agent:
            raise ValueError("SEC requests require a descriptive User-Agent containing a contact email.")
        cik = CIKS[ticker]
        url = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json"
        request = Request(url, headers={"User-Agent": user_agent, "Accept-Encoding": "identity"})
        with urlopen(request, timeout=30) as response:  # nosec B310 - fixed SEC endpoint
            payload = json.load(response)
        facts = payload.get("facts", {}).get("us-gaap", {})
        revenues = _series(facts, ("RevenueFromContractWithCustomerExcludingAssessedTax", "SalesRevenueNet", "Revenues"), duration=True)
        gross_profits = _series(facts, ("GrossProfit",), duration=True)
        inventories = _series(facts, ("InventoryNet", "InventoryFinishedGoodsNetOfReserves"), duration=False)
        common_ends = sorted(set(revenues) & set(gross_profits) & set(inventories))
        citation_id = f"sec-companyfacts-{ticker}-{as_of.isoformat()}"
        citation = Citation(
            source_id=citation_id,
            title=f"SEC Company Facts API for {ticker}", url=url, published_at=as_of, source_type="sec",
            excerpt="Company Facts API retrieval used for reported revenue, gross profit, and inventory; filing dates are retained for point-in-time filtering.",
        )
        observations: list[FundamentalObservation] = []
        for period_end in common_ends:
            values = (revenues[period_end], gross_profits[period_end], inventories[period_end])
            available_at = max(item["filed"] for item in values)
            if available_at > as_of:
                continue
            observations.append(FundamentalObservation(
                ticker=ticker, period_end=period_end, available_at=available_at,
                revenue_m=round(float(values[0]["val"]) / 1_000_000, 2),
                gross_profit_m=round(float(values[1]["val"]) / 1_000_000, 2),
                inventory_m=round(float(values[2]["val"]) / 1_000_000, 2),
                guidance_midpoint_m=None, citation_ids=(citation_id,), fiscal_label=values[0].get("fp", "UNKNOWN"),
            ))
        return observations, {citation_id: citation}


def _series(facts: dict, tags: tuple[str, ...], duration: bool) -> dict[date, dict]:
    """Select the latest 10-Q/10-K fact per period-end from a candidate concept."""
    candidates = []
    for tag in tags:
        units = facts.get(tag, {}).get("units", {}).get("USD", [])
        for item in units:
            if item.get("form") not in {"10-Q", "10-K"}:
                continue
            if duration and not item.get("start"):
                continue
            try:
                candidates.append({**item, "end": date.fromisoformat(item["end"]), "filed": date.fromisoformat(item["filed"])})
            except (KeyError, TypeError, ValueError):
                continue
    result: dict[date, dict] = {}
    for item in candidates:
        previous = result.get(item["end"])
        if previous is None or item["filed"] > previous["filed"]:
            result[item["end"]] = item
    return result

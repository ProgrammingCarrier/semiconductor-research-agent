"""Illustrative offline fixture. It is intentionally not investment-grade market data."""

from __future__ import annotations

from datetime import date, timedelta

from .models import Citation, EarningsOutcome, FundamentalObservation


UNIVERSE = ("NVDA", "AMD", "INTC", "AVGO", "QCOM", "MU", "TXN", "ON")


def demo_data() -> tuple[list[FundamentalObservation], list[EarningsOutcome], dict[str, Citation]]:
    """Return a deterministic fixture for a complete offline demo and test suite.

    Values are synthetic, labelled as such in outputs, and exist solely to prove the
    workflow. Replace this fixture with SEC and licensed market-data adapters before
    distributing any research.
    """
    available_dates = [
        date(2024, 5, 20), date(2024, 8, 20), date(2024, 11, 20),
        date(2025, 2, 20), date(2025, 5, 20), date(2025, 8, 20),
    ]
    period_ends = [
        date(2024, 4, 30), date(2024, 7, 31), date(2024, 10, 31),
        date(2025, 1, 31), date(2025, 4, 30), date(2025, 7, 31),
    ]
    bases = {
        "NVDA": (20_000, 9_000, 0.72, 5_000), "AMD": (5_500, 1_600, 0.53, 5_800),
        "INTC": (13_000, 4_800, 0.41, 11_500), "AVGO": (12_000, 7_500, 0.66, 1_900),
        "QCOM": (9_000, 5_000, 0.56, 5_400), "MU": (6_000, 1_800, 0.31, 8_100),
        "TXN": (4_000, 2_400, 0.60, 4_300), "ON": (1_900, 850, 0.45, 2_100),
    }
    # Revenue growth, margin progression, inventory growth, and guidance progression.
    # Different patterns make peer comparison and walk-forward behavior non-trivial.
    patterns = {
        "NVDA": ([.05, .08, .10, .07, .06, .04], [.00, .01, .01, .00, .01, -.005], [-.03, -.04, -.02, .01, -.01, .02], [.04, .08, .09, .05, .05, .02]),
        "AMD":  ([.02, .03, .02, .04, .03, .02], [.00, .005, .00, .005, .00, -.005], [.02, .03, .01, .02, .01, .04], [.01, .02, .01, .03, .02, .01]),
        "INTC": ([.00, -.02, -.01, .01, .02, .03], [-.01, -.01, .00, .005, .01, .01], [.03, .04, .02, .00, -.02, -.03], [-.03, -.02, -.01, .01, .02, .02]),
        "AVGO": ([.03, .04, .05, .04, .05, .04], [.005, .005, .005, .00, .005, .005], [-.01, -.01, .00, .01, .00, .01], [.03, .04, .05, .03, .04, .03]),
        "QCOM": ([.01, .02, .00, .02, .01, .02], [.00, .005, -.005, .005, .00, .005], [.01, .02, .03, .01, .02, .01], [.00, .02, -.01, .02, .01, .02]),
        "MU":   ([.04, .06, .08, .05, .03, .02], [.01, .02, .02, .01, .005, .00], [-.04, -.05, -.03, -.02, .01, .03], [.06, .08, .10, .06, .03, .01]),
        "TXN":  ([.00, -.01, -.02, .00, .01, .01], [-.005, -.005, .00, .005, .005, .00], [.02, .03, .02, .01, .00, .02], [-.01, -.01, .00, .01, .01, .00]),
        "ON":   ([.01, -.02, -.03, -.01, .00, .02], [-.01, -.01, -.005, .00, .005, .005], [.04, .05, .03, .02, .00, -.01], [-.02, -.03, -.02, -.01, .01, .02]),
    }

    observations: list[FundamentalObservation] = []
    outcomes: list[EarningsOutcome] = []
    citations: dict[str, Citation] = {}
    for index, ticker in enumerate(UNIVERSE):
        revenue, gross_profit, margin, inventory = bases[ticker]
        revenue_growth, margin_change, inventory_growth, guidance_growth = patterns[ticker]
        guidance = revenue * 1.02
        for quarter, (available_at, period_end) in enumerate(zip(available_dates, period_ends), start=1):
            revenue *= 1 + revenue_growth[quarter - 1]
            margin = max(.12, min(.82, margin + margin_change[quarter - 1]))
            gross_profit = revenue * margin
            inventory *= 1 + inventory_growth[quarter - 1]
            guidance *= 1 + guidance_growth[quarter - 1]
            fundamental_id = f"demo-{ticker}-{quarter}-fundamentals"
            outcome_id = f"demo-{ticker}-{quarter}-outcome"
            citations[fundamental_id] = Citation(
                source_id=fundamental_id,
                title=f"Synthetic {ticker} quarter {quarter} fundamentals",
                url="https://www.sec.gov/edgar/search/",
                published_at=available_at,
                source_type="sec",
                excerpt=(f"Illustrative fixture: {ticker} revenue, gross profit, inventory, and forward guidance "
                         "were available on this date. Not a real filing or recommendation."),
            )
            event_date = available_at + timedelta(days=75)
            # The next outcome is correlated, but not perfectly, with the reported drivers.
            driver = -inventory_growth[quarter - 1] + margin_change[quarter - 1] * 8 + guidance_growth[quarter - 1]
            noise = ((index * 3 + quarter) % 5 - 2) * .012
            surprise = driver * .45 + noise
            adjusted_return = driver * .75 + noise * 1.4
            citations[outcome_id] = Citation(
                source_id=outcome_id,
                title=f"Synthetic {ticker} next earnings outcome after quarter {quarter}",
                url="https://www.sec.gov/edgar/search/",
                published_at=event_date,
                source_type="earnings_release",
                excerpt=(f"Illustrative fixture: {ticker} actual versus consensus EPS and 5-day market-adjusted return. "
                         "Not a real earnings release or investment recommendation."),
            )
            observations.append(FundamentalObservation(
                ticker=ticker, period_end=period_end, available_at=available_at,
                revenue_m=round(revenue, 2), gross_profit_m=round(gross_profit, 2),
                inventory_m=round(inventory, 2), guidance_midpoint_m=round(guidance, 2),
                citation_ids=(fundamental_id,), fiscal_label=f"DEMO-Q{quarter}",
            ))
            consensus = round(.75 + index * .06 + quarter * .015, 3)
            outcomes.append(EarningsOutcome(
                ticker=ticker, event_date=event_date, actual_eps=round(consensus * (1 + surprise), 3),
                consensus_eps=consensus, stock_return_5d=round(adjusted_return + .01, 4),
                benchmark_return_5d=.01, citation_ids=(outcome_id,),
            ))
    return observations, outcomes, citations

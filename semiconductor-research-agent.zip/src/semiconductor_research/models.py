from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import date
from typing import Literal


def iso(value: date) -> str:
    return value.isoformat()


@dataclass(frozen=True)
class Citation:
    """A source whose availability date enables point-in-time verification."""

    source_id: str
    title: str
    url: str
    published_at: date
    source_type: Literal["sec", "earnings_release", "transcript", "market", "industry"]
    excerpt: str

    def to_dict(self) -> dict:
        result = asdict(self)
        result["published_at"] = iso(self.published_at)
        return result


@dataclass(frozen=True)
class FundamentalObservation:
    """A single company-quarter as known on filing/release date, not restated later."""

    ticker: str
    period_end: date
    available_at: date
    revenue_m: float | None
    gross_profit_m: float | None
    inventory_m: float | None
    guidance_midpoint_m: float | None
    citation_ids: tuple[str, ...]
    fiscal_label: str

    @property
    def gross_margin(self) -> float | None:
        if self.revenue_m is None or self.gross_profit_m is None or self.revenue_m <= 0:
            return None
        return self.gross_profit_m / self.revenue_m

    def to_dict(self) -> dict:
        result = asdict(self)
        result["period_end"] = iso(self.period_end)
        result["available_at"] = iso(self.available_at)
        result["gross_margin"] = self.gross_margin
        return result


@dataclass(frozen=True)
class EarningsOutcome:
    ticker: str
    event_date: date
    actual_eps: float
    consensus_eps: float
    stock_return_5d: float
    benchmark_return_5d: float
    citation_ids: tuple[str, ...]

    @property
    def eps_surprise_pct(self) -> float:
        denominator = max(abs(self.consensus_eps), 0.01)
        return (self.actual_eps - self.consensus_eps) / denominator

    @property
    def market_adjusted_return_5d(self) -> float:
        return self.stock_return_5d - self.benchmark_return_5d

    def to_dict(self) -> dict:
        result = asdict(self)
        result["event_date"] = iso(self.event_date)
        result["eps_surprise_pct"] = self.eps_surprise_pct
        result["market_adjusted_return_5d"] = self.market_adjusted_return_5d
        return result


@dataclass(frozen=True)
class SignalRecord:
    ticker: str
    available_at: date
    period_end: date
    inventory_qoq: float | None
    gross_margin_delta_bps: float | None
    guidance_change: float | None
    composite_score: float | None
    outcome: EarningsOutcome | None
    citation_ids: tuple[str, ...]

    @property
    def positive_outcome(self) -> bool | None:
        if self.outcome is None:
            return None
        return self.outcome.eps_surprise_pct > 0 and self.outcome.market_adjusted_return_5d > 0

    def to_dict(self) -> dict:
        result = asdict(self)
        result["available_at"] = iso(self.available_at)
        result["period_end"] = iso(self.period_end)
        result["outcome"] = self.outcome.to_dict() if self.outcome else None
        result["positive_outcome"] = self.positive_outcome
        return result


@dataclass(frozen=True)
class DataIssue:
    severity: Literal["error", "warning"]
    ticker: str
    message: str
    field: str | None = None


@dataclass
class ResearchResult:
    as_of: date
    signals: list[SignalRecord]
    citations: dict[str, Citation]
    data_issues: list[DataIssue] = field(default_factory=list)
    walk_forward: dict = field(default_factory=dict)


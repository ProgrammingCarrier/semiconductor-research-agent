from __future__ import annotations

from collections import defaultdict
from datetime import date
from statistics import mean

from .models import EarningsOutcome, FundamentalObservation, SignalRecord


class FundamentalAnalysisAgent:
    """Transforms only information public by `as_of` into comparable earnings signals."""

    def build_signals(
        self,
        observations: list[FundamentalObservation],
        outcomes: list[EarningsOutcome],
        as_of: date,
    ) -> list[SignalRecord]:
        by_ticker: dict[str, list[FundamentalObservation]] = defaultdict(list)
        for observation in observations:
            if observation.available_at <= as_of:
                by_ticker[observation.ticker].append(observation)
        outcomes_by_ticker: dict[str, list[EarningsOutcome]] = defaultdict(list)
        for outcome in outcomes:
            if outcome.event_date <= as_of:
                outcomes_by_ticker[outcome.ticker].append(outcome)

        signals: list[SignalRecord] = []
        for ticker, rows in by_ticker.items():
            rows.sort(key=lambda row: (row.period_end, row.available_at))
            ticker_outcomes = sorted(outcomes_by_ticker[ticker], key=lambda row: row.event_date)
            for previous, current in zip(rows, rows[1:]):
                inventory_qoq = _pct_change(current.inventory_m, previous.inventory_m)
                margin_change = _margin_bps(current, previous)
                guidance_change = _pct_change(current.guidance_midpoint_m, previous.guidance_midpoint_m)
                components = []
                if inventory_qoq is not None:
                    components.append(-inventory_qoq)
                if margin_change is not None:
                    components.append(margin_change / 1_000)
                if guidance_change is not None:
                    components.append(guidance_change)
                next_outcome = next((row for row in ticker_outcomes if row.event_date > current.available_at), None)
                citation_ids = current.citation_ids + (next_outcome.citation_ids if next_outcome else ())
                signals.append(SignalRecord(
                    ticker=ticker, available_at=current.available_at, period_end=current.period_end,
                    inventory_qoq=inventory_qoq, gross_margin_delta_bps=margin_change,
                    guidance_change=guidance_change,
                    composite_score=mean(components) if components else None,
                    outcome=next_outcome, citation_ids=citation_ids,
                ))
        return sorted(signals, key=lambda signal: (signal.available_at, signal.ticker))


def peer_zscores(signals: list[SignalRecord]) -> dict[tuple[str, date], float | None]:
    """Peer-standardize the composite score within each research date."""
    by_date: dict[date, list[SignalRecord]] = defaultdict(list)
    for signal in signals:
        if signal.composite_score is not None:
            by_date[signal.available_at].append(signal)
    result: dict[tuple[str, date], float | None] = {}
    for available_at, group in by_date.items():
        scores = [signal.composite_score for signal in group if signal.composite_score is not None]
        average = mean(scores)
        variance = mean((score - average) ** 2 for score in scores)
        stddev = variance ** .5
        for signal in group:
            result[(signal.ticker, available_at)] = None if stddev == 0 else (signal.composite_score - average) / stddev
    return result


def _pct_change(current: float | None, previous: float | None) -> float | None:
    if current is None or previous is None or previous == 0:
        return None
    return (current - previous) / abs(previous)


def _margin_bps(current: FundamentalObservation, previous: FundamentalObservation) -> float | None:
    if current.gross_margin is None or previous.gross_margin is None:
        return None
    return (current.gross_margin - previous.gross_margin) * 10_000

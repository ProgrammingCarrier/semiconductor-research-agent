"""Auditable, point-in-time semiconductor earnings research."""

from .pipeline import ResearchPipeline

__all__ = ["ResearchPipeline"]


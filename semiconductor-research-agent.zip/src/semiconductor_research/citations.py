from __future__ import annotations

import re
from datetime import date

from .models import Citation, DataIssue


class CitationVerificationAgent:
    """Checks source existence, timing, and bare-minimum source metadata."""

    def verify(self, citation_ids: set[str], citations: dict[str, Citation], as_of: date) -> list[DataIssue]:
        issues: list[DataIssue] = []
        for source_id in sorted(citation_ids):
            citation = citations.get(source_id)
            if citation is None:
                issues.append(DataIssue("error", "ALL", f"Missing citation: {source_id}", "citation_ids"))
                continue
            if citation.published_at > as_of:
                issues.append(DataIssue("error", "ALL", f"Citation {source_id} was published after the research date.", "published_at"))
            if not citation.url.startswith("https://"):
                issues.append(DataIssue("warning", "ALL", f"Citation {source_id} does not use an HTTPS URL.", "url"))
            if len(citation.excerpt.strip()) < 20:
                issues.append(DataIssue("warning", "ALL", f"Citation {source_id} has too little supporting text.", "excerpt"))
        return issues


class EarningsMaterialRetriever:
    """Small, dependency-free lexical retriever for earnings-release/transcript excerpts.

    Replace it with an embedding retriever later without changing citation objects.
    """

    def search(self, query: str, citations: dict[str, Citation], ticker: str | None = None, limit: int = 3) -> list[Citation]:
        terms = set(re.findall(r"[a-z0-9]+", query.lower()))
        scored: list[tuple[int, Citation]] = []
        for citation in citations.values():
            corpus = f"{citation.title} {citation.excerpt}".lower()
            if ticker and ticker.lower() not in corpus and ticker.lower() not in citation.source_id.lower():
                continue
            score = sum(term in corpus for term in terms)
            if score:
                scored.append((score, citation))
        return [citation for _, citation in sorted(scored, key=lambda pair: (-pair[0], pair[1].source_id))[:limit]]

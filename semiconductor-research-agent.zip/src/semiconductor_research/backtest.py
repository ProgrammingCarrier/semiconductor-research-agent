from __future__ import annotations

from collections import defaultdict
from statistics import median

from .models import SignalRecord


class WalkForwardValidator:
    """Evaluates a simple score rule using only thresholds known before each fold."""

    def evaluate(self, signals: list[SignalRecord], minimum_history: int = 8) -> dict:
        by_date: dict = defaultdict(list)
        for signal in signals:
            if signal.composite_score is not None and signal.positive_outcome is not None:
                by_date[signal.available_at].append(signal)

        historical: list[SignalRecord] = []
        predictions: list[dict] = []
        folds: list[dict] = []
        for available_at in sorted(by_date):
            current = by_date[available_at]
            if len(historical) >= minimum_history:
                threshold = median([item.composite_score for item in historical if item.composite_score is not None])
                fold_predictions = []
                for signal in current:
                    predicted_positive = bool(signal.composite_score is not None and signal.composite_score >= threshold)
                    correct = predicted_positive == signal.positive_outcome
                    item = {
                        "ticker": signal.ticker,
                        "as_of": available_at.isoformat(),
                        "threshold": round(threshold, 6),
                        "predicted_positive": predicted_positive,
                        "actual_positive": signal.positive_outcome,
                        "correct": correct,
                    }
                    predictions.append(item)
                    fold_predictions.append(item)
                folds.append({
                    "as_of": available_at.isoformat(),
                    "training_observations": len(historical),
                    "threshold": round(threshold, 6),
                    "accuracy": round(sum(item["correct"] for item in fold_predictions) / len(fold_predictions), 4),
                })
            historical.extend(current)
        if not predictions:
            return {"status": "insufficient_history", "minimum_history": minimum_history, "folds": [], "predictions": []}
        positive_predictions = [item for item in predictions if item["predicted_positive"]]
        true_positives = [item for item in positive_predictions if item["actual_positive"]]
        return {
            "status": "ok",
            "minimum_history": minimum_history,
            "evaluated_predictions": len(predictions),
            "accuracy": round(sum(item["correct"] for item in predictions) / len(predictions), 4),
            "precision_when_positive": round(len(true_positives) / len(positive_predictions), 4) if positive_predictions else None,
            "positive_prediction_rate": round(len(positive_predictions) / len(predictions), 4),
            "folds": folds,
            "predictions": predictions,
        }

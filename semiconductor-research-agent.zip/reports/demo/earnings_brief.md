# U.S. Semiconductor Sector Earnings Brief

**As of:** 2025-12-31  
**Dataset:** Synthetic offline fixture - never use for investment decisions

> This package is a research workflow demonstration, not investment advice. The bundled fixture is synthetic and must be replaced with licensed and primary-source data before any investment use.

## Latest peer comparison

| Ticker | Inventory QoQ | Gross-margin delta | Guidance change | Composite | Peer z-score | Next EPS surprise | 5D market-adjusted return |
|---|---:|---:|---:|---:|---:|---:|---:|
| INTC | -3.0% | 100 bps | 2.0% | 0.050 | 1.730 | 5.8% | 9.8% |
| ON | -1.0% | 50 bps | 2.0% | 0.027 | 0.771 | 3.2% | 5.2% |
| AVGO | 1.0% | 50 bps | 3.0% | 0.023 | 0.634 | 0.3% | 1.1% |
| QCOM | 1.0% | 50 bps | 2.0% | 0.020 | 0.497 | 3.4% | 5.4% |
| TXN | 2.0% | 0 bps | 0.0% | -0.007 | -0.599 | 1.5% | 1.9% |
| MU | 3.0% | -0 bps | 1.0% | -0.007 | -0.600 | -2.1% | -3.2% |
| NVDA | 2.0% | -50 bps | 2.0% | -0.017 | -1.011 | -3.0% | -4.7% |
| AMD | 4.0% | -50 bps | 1.0% | -0.027 | -1.422 | -0.8% | -1.9% |

## Read-through and counter-theses

- **Relative leader: INTC.** Its composite score combines -3.0% inventory change, 100 bps margin movement, and 2.0% guidance movement. **Counter-thesis:** the score can mistake mix or accounting timing for sustainable demand; corroborate with management commentary and end-demand indicators.
- **Relative laggard: AMD.** The same driver stack is weaker on this observation. **Counter-thesis:** an inventory build may be intentional channel positioning, while short-term margin pressure can precede utilization recovery.
- **Decision rule:** treat the composite as a triage signal, not a price target. Require a cited earnings-material review, estimate-revision context, and a liquidity/risk check before acting.

## Point-in-time and validation controls

- Fundamentals are admitted only when `available_at <= as_of`; future filings are excluded before signals are calculated.
- A score links to the first *subsequent* earnings outcome, avoiding use of same-event reporting details to explain that event.
- The walk-forward threshold is the median composite score in earlier folds only; it is never calibrated on the current fold.
- Data-quality checks flag duplicate periods, impossible values, missing sources, and future-dated observations. Citation verification checks existence, timing, HTTPS URLs, and support excerpts.

## Walk-forward result

```json
{
  "status": "ok",
  "minimum_history": 8,
  "evaluated_predictions": 32,
  "accuracy": 0.875,
  "precision_when_positive": 0.95,
  "positive_prediction_rate": 0.625,
  "folds": [
    {
      "as_of": "2024-11-20",
      "training_observations": 8,
      "threshold": 0.015,
      "accuracy": 0.875
    },
    {
      "as_of": "2025-02-20",
      "training_observations": 16,
      "threshold": 0.006667,
      "accuracy": 0.875
    },
    {
      "as_of": "2025-05-20",
      "training_observations": 24,
      "threshold": 0.015001,
      "accuracy": 0.875
    },
    {
      "as_of": "2025-08-20",
      "training_observations": 32,
      "threshold": 0.018331,
      "accuracy": 0.875
    }
  ]
}
```

## Source register (latest peer set)

- [Synthetic AMD quarter 6 fundamentals](https://www.sec.gov/edgar/search/) - available 2025-08-20 - `demo-AMD-6-fundamentals`
- [Synthetic AMD next earnings outcome after quarter 6](https://www.sec.gov/edgar/search/) - available 2025-11-03 - `demo-AMD-6-outcome`
- [Synthetic AVGO quarter 6 fundamentals](https://www.sec.gov/edgar/search/) - available 2025-08-20 - `demo-AVGO-6-fundamentals`
- [Synthetic AVGO next earnings outcome after quarter 6](https://www.sec.gov/edgar/search/) - available 2025-11-03 - `demo-AVGO-6-outcome`
- [Synthetic INTC quarter 6 fundamentals](https://www.sec.gov/edgar/search/) - available 2025-08-20 - `demo-INTC-6-fundamentals`
- [Synthetic INTC next earnings outcome after quarter 6](https://www.sec.gov/edgar/search/) - available 2025-11-03 - `demo-INTC-6-outcome`
- [Synthetic MU quarter 6 fundamentals](https://www.sec.gov/edgar/search/) - available 2025-08-20 - `demo-MU-6-fundamentals`
- [Synthetic MU next earnings outcome after quarter 6](https://www.sec.gov/edgar/search/) - available 2025-11-03 - `demo-MU-6-outcome`
- [Synthetic NVDA quarter 6 fundamentals](https://www.sec.gov/edgar/search/) - available 2025-08-20 - `demo-NVDA-6-fundamentals`
- [Synthetic NVDA next earnings outcome after quarter 6](https://www.sec.gov/edgar/search/) - available 2025-11-03 - `demo-NVDA-6-outcome`
- [Synthetic ON quarter 6 fundamentals](https://www.sec.gov/edgar/search/) - available 2025-08-20 - `demo-ON-6-fundamentals`
- [Synthetic ON next earnings outcome after quarter 6](https://www.sec.gov/edgar/search/) - available 2025-11-03 - `demo-ON-6-outcome`
- [Synthetic QCOM quarter 6 fundamentals](https://www.sec.gov/edgar/search/) - available 2025-08-20 - `demo-QCOM-6-fundamentals`
- [Synthetic QCOM next earnings outcome after quarter 6](https://www.sec.gov/edgar/search/) - available 2025-11-03 - `demo-QCOM-6-outcome`
- [Synthetic TXN quarter 6 fundamentals](https://www.sec.gov/edgar/search/) - available 2025-08-20 - `demo-TXN-6-fundamentals`
- [Synthetic TXN next earnings outcome after quarter 6](https://www.sec.gov/edgar/search/) - available 2025-11-03 - `demo-TXN-6-outcome`

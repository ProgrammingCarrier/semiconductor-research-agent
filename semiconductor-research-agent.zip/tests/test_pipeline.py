from __future__ import annotations

from datetime import date
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from semiconductor_research.models import FundamentalObservation
from semiconductor_research.pipeline import ResearchPipeline
from semiconductor_research.quality import DataQualityAgent
from semiconductor_research.reporting import write_research_package
from semiconductor_research.sample_data import demo_data
from semiconductor_research.sec import _series


class ResearchPipelineTests(unittest.TestCase):
    def setUp(self) -> None:
        self.observations, self.outcomes, self.citations = demo_data()

    def test_demo_builds_expected_coverage_and_walk_forward_folds(self) -> None:
        result = ResearchPipeline().run(self.observations, self.outcomes, self.citations, date(2025, 12, 31))
        self.assertEqual(len(result.signals), 40)
        self.assertEqual({signal.ticker for signal in result.signals}, {"NVDA", "AMD", "INTC", "AVGO", "QCOM", "MU", "TXN", "ON"})
        self.assertEqual(result.walk_forward["status"], "ok")
        self.assertGreater(result.walk_forward["evaluated_predictions"], 0)
        self.assertFalse([issue for issue in result.data_issues if issue.severity == "error"])

    def test_as_of_filter_prevents_future_observations_and_outcomes(self) -> None:
        result = ResearchPipeline().run(self.observations, self.outcomes, self.citations, date(2024, 9, 1))
        self.assertTrue(all(signal.available_at <= date(2024, 9, 1) for signal in result.signals))
        self.assertTrue(all(signal.outcome is None or signal.outcome.event_date <= date(2024, 9, 1) for signal in result.signals))
        self.assertEqual(len(result.signals), 8)

    def test_quality_agent_rejects_impossible_fundamentals(self) -> None:
        bad = FundamentalObservation(
            ticker="BAD", period_end=date(2025, 3, 31), available_at=date(2025, 4, 1),
            revenue_m=1, gross_profit_m=2, inventory_m=-3, guidance_midpoint_m=None,
            citation_ids=(), fiscal_label="Q1",
        )
        issues = DataQualityAgent().validate([bad], date(2025, 5, 1))
        self.assertGreaterEqual(sum(issue.severity == "error" for issue in issues), 2)

    def test_package_writes_dashboard_json_and_brief(self) -> None:
        result = ResearchPipeline().run(self.observations, self.outcomes, self.citations, date(2025, 12, 31))
        with TemporaryDirectory() as temporary:
            output = Path(temporary)
            write_research_package(result, output)
            self.assertIn("Semiconductor Sector Research Agent", (output / "dashboard.html").read_text())
            self.assertIn("Latest peer comparison", (output / "earnings_brief.md").read_text())
            self.assertTrue((output / "research.json").is_file())

    def test_sec_series_uses_latest_filed_fact_per_period(self) -> None:
        facts = {"Revenues": {"units": {"USD": [
            {"form": "10-Q", "start": "2025-01-01", "end": "2025-03-31", "filed": "2025-04-20", "val": 10},
            {"form": "10-Q", "start": "2025-01-01", "end": "2025-03-31", "filed": "2025-04-25", "val": 11},
        ]}}}
        series = _series(facts, ("Revenues",), duration=True)
        self.assertEqual(series[date(2025, 3, 31)]["val"], 11)


if __name__ == "__main__":
    unittest.main()
